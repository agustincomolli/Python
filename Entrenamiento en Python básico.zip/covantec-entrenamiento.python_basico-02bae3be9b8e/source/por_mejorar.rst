Tareas pendientes
=================

Esta documentación tiene las siguientes tareas pendientes por hacer 
para mejorar la calidad de la misma:

.. todoList::
