.. -*- coding: utf-8 -*-


.. _python_decoradores:

Decoradores
-----------

Un decorador es una función Python permite que agregar funcionalidad a otra función, 
pero sin modificarla. También, esto es llamado meta-programación, por que parte del 
programa trata de modificar a otro al momento de compilar.

Para llamar un decorador se utiliza el signo de arroba (@).

Los decoradores en Python son discutidos y definidos en el PEP-318. https://www.python.org/dev/peps/pep-0318/

.. todo::
    TODO Terminar de escribir esta sección
