.. -*- coding: utf-8 -*-


.. _python_leccion6:

Introspección a la depuración con pdb
=====================================

En Python puede realizar depuración de programas por defecto usando el módulo ``pdb``.

En esta lección se describen como hacer depuración a programas en el lenguaje Python, 
mostrando ejemplos prácticos y útiles. A continuación el temario de esta lección:

.. toctree::
   :maxdepth: 2

   depuracion
