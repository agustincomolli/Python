# -*- coding: utf8 -*-

import sys

print sys.argv
