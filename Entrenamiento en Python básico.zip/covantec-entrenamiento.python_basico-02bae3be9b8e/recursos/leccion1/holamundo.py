print ("Hola Mundo")

