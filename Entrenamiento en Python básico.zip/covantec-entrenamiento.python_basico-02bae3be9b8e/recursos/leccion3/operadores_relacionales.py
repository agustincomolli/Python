"""Operadores relacionales o comparación"""

a, b, a1, b1, c1 = 5, 5, 7, 3, 3
cadena1, cadena2 = 'Hola', 'Adiós'
lista1, lista2 = [1, 'Lista Python', 23], [11, 'Lista Python', 23]

# Igual
c = a == b
print (c)

cadenas = cadena1 == cadena2
print (cadenas)

listas = lista1 == lista2
print (listas)

# Diferente
d = a1 != b
print (d)

cadena0 = cadena1 != cadena2
print (cadena0)

# Menor que
f = b1 < a1
print (f)

# Mayor que
e = a1 > b1
print (e)

# Menor o igual que
h = b1 <= c1
print (h)

# Mayor o igual que
g = b1 >= c1
print (g)

